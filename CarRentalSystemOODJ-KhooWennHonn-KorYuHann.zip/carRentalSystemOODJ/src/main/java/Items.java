/**
 *
 * @author KhooWennHonn(TP065779)
 */
public interface Items {
    abstract void appendToFile();
}
