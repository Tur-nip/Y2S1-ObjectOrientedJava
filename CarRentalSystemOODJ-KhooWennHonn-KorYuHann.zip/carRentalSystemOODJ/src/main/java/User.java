/**
 *
 * @author KhooWennHonn(TP065779)
 */
public abstract class User {
    abstract void appendFile();
}
